# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 18:39:23 2019

@author: alonb
"""


import pandas as pd
df = pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/wdbc.data', header = None)

## Assign 30 features to X using label incoder transform MB to integers

from sklearn.preprocessing import LabelEncoder


X = df.loc[:, 2:].values
y = df.loc[:,1].values
le = LabelEncoder()
y = le.fit_transform(y)

le.transform(['M', 'B'])

## Split into 80/20 training test sets

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.20, random_state = 1)

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

## Pipeline takes a list of tuples (aribitary identifier, function)
pipe_lr = Pipeline([('scl', StandardScaler()),
                   ('pca', PCA(n_components=2)),
                   ('clf', LogisticRegression(solver='lbfgs',random_state = 1))])


pipe_lr.fit(X_train, y_train)
print('\n Test Accuracy: %.3f' % pipe_lr.score(X_test, y_test))





